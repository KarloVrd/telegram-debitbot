
# DebitBot
Keep track of debts between you and your friends with this Telegram bot. Record payments in the bot instead of exchanging physical cash. The bot tracks balances, making it easy to keep track of debts and resolve them.


## Usage

In Telegram aplication, navigate to Search and type `@OmegaDebitBot`. Click on the bot and then click on the Start button. 

You can also add it to group chat so anybody can make changes and record payments. 
Bot only tracks messages that start with `/` so it cannot see your private messages. You can add it to active friend group but I advise having separate group because of clarity.

For more details about commands type `/h` or `/help` in bot's chat.