from DebitHandler import DataInteractInterface
import boto3
import os

talbe_name = os.environ["DYNAMODB_TABLE_NAME"]
'''
states_table = 
{
    {
        "chat_id": 123456789,
        "state": {
            "Karlo": 0,
            "Jura": 0
            }
    },
    {
        "chat_id": 123456789,
        "state": {
            "Karlo": 0,
            "Jura": 0
        }
    }
}
'''
class DynamoDBDataClass(DataInteractInterface):
    def __init__(self):
        self.dynamodb = boto3.resource("dynamodb")
        self.table = self.dynamodb.Table(talbe_name)

    def load_state(self, chat_id) -> dict:
        response = self.table.get_item(
            Key={"chat_id": chat_id}
        )
        if "Item" in response:
            return response["Item"]["state"]
        else:
            return dict()

    def save_state(self, state, chat_id):
        self.table.update_item(
            Key={"chat_id": chat_id},
            AttributeUpdates={
            'state': {
                'Value': state,
                'Action': 'PUT'
            }
    }
        )

    def load_groups(self, chat_id) -> dict:
        response = self.table.get_item(
            Key={"chat_id": chat_id},
        )
        if "Item" in response:
            return response["Item"]["groups"]
        else:
            return dict()

    def save_groups(self, groups, chat_id):
        self.table.update_item(
            Key={"chat_id": chat_id},
            AttributeUpdates={
                'groups': {
                    'Value': groups,
                    'Action': 'PUT'
                }
            }
        )

    def load_log(self, chat_id, reverse_index) -> dict:
        response = self.table.get_item(
            Key={"chat_id": chat_id}
        )
        index = -1 - reverse_index
        if "Item" in response:
            return response["Item"]["logs"][index]
        else:
            return dict()

    def save_log(self, message, sender_id, chat_id):
        self.logs_table.put_item(
            Item={
                "chat_id": chat_id,
                "logs": [
                    {
                        "message": message,
                        "sender_id": sender_id
                    }
                ]
            }
        )

    def load_all_states(self) -> dict:
        response = self.states_table.scan()
        return response["Items"]

    def load_all_groups(self) -> dict:
        response = self.groups_table.scan()
        return response["Items"]

    def load_all_logs(self) -> dict:
        response = self.logs_table.scan()
        return response["Items"]

    def load_all(self) -> dict:
        return {
            "states": self.load_all_states(),
            "groups": self.load_all_groups(),
            "logs": self.load_all_logs()
        }

    def delete_all(self):
        self.states_table.delete()
        self.groups_table.delete()
        self.logs_table.delete()

    def create_all(self):
        self.states_table.create()
        self.groups_table.create()
        self.logs_table.create()

    def delete_state(self, chat_id):
        self.states_table.delete_item(
            Key={"chat_id": chat_id}
        )

    def delete_groups(self, chat_id):
        self.groups_table.delete_item(
            Key={"chat_id": chat_id})