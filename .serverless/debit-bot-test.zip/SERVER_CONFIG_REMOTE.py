database = "Karlo13$debitwallet"
user = "Karlo13"
password = "xtijaijax"
host = "Karlo13.mysql.pythonanywhere-services.com"
root = "https://karlo13.pythonanywhere.com"
botApiPath = "/home/Karlo13/OmegaDebitBot"
secret_key = 'bipidibupidi'
salt = 'Th@xhl?7D3T)'