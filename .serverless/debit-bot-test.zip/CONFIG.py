relativePath = "/storage/emulated/0/Moji programi/DebitBot_v6"
#relativePath = "/home/Karlo13/OmegaDebitBot"
TOKEN = "1647743462:AAFcjy2b-PhRiYN2z9dkMhTwNgEfD3mPreY"  # Token of your bot
URL = "https://api.telegram.org/bot{}/".format(TOKEN)
testerId = 1217535067