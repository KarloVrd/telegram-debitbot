database="debitbotdb"
user="root"
password="xtijaijax"
host ="localhost"
root = "http://127.0.0.1:5000"
botApiPath = 'G:/My Drive/Programi/Telegram bots/OmegaDebitBot/v2/v2.3'
secret_key = 'bipidibupidi'
salt = 'Th@xhl?7D3T)'